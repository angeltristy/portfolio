import java.io.File;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class ReadTabularFileExample {

    public static void main(String args[]) {
        // Open the file

        Scanner infile = null;
        try {
            infile = new Scanner(new File("Tutorial-FileIO/temperature.txt"));
        }
        catch (FileNotFoundException e) {
            System.out.println("Error: file not found.");
            return;
        }

        // Read lines.
        ArrayList<TempRecord> records = new ArrayList<TempRecord>();
        while(infile.hasNextLine()) {
            // Read all the data from one line
            String month,year;
            float minTemp,maxTemp;

            try { month = infile.next(); }
            catch(InputMismatchException e) {
                System.out.println(e.getMessage());
                return;
            }
            try { year = infile.next(); }
            catch(InputMismatchException e) {
                System.out.println(e.getMessage());
                return;
           }
            try { minTemp = infile.nextFloat(); }
            catch(InputMismatchException e) {
                System.out.println(e.getMessage());
                return;
            }
            try { maxTemp = infile.nextFloat(); }
            catch(InputMismatchException e) {
                System.out.println(e.getMessage());
                return;
            }

            TempRecord r = new TempRecord(month, year, minTemp, maxTemp);
            records.add(r);

        }

        for(TempRecord item: records) {
            System.out.println(item);
        }
    }
}
