import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedWriter;

public class WriteFileExample {

    public static void main(String args[]) {

        String s = "The answer to the ultimate question of life,"+
                "the universe, and everything is:";
        int fortyTwo = 42;
        float fortyTwoPointZero = 42.0f;


        // Open the file

        BufferedWriter outfile = null;
        try {
            outfile = new BufferedWriter(new FileWriter("Tutorial-FileIO/ultimateanswer.txt"));
        }
        catch (IOException e) {
            System.out.println("Error: file cannot be opened.");
            return;
        }

        try {
            outfile.write("The answer to the ultimate question of life, the universe, and everything is:\n");
            outfile.write( new Integer(fortyTwo).toString()+"\n");
            outfile.write( new Float(fortyTwoPointZero).toString() + "\n");
            outfile.close();

        }
        catch (IOException e) {
            System.out.println("Dang, something went wrong.");
            return;
        }
    }
}