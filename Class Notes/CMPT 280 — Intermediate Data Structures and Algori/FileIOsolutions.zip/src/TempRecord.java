public class TempRecord {
    protected String month;
    protected String year;
    protected float minTemp;
    protected float maxTemp;


    public TempRecord(String month, String year, float minTemp, float maxTemp) {
        this.month = month;
        this.year = year;
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public float getMinTemp() {
        return minTemp;
    }

    public void setMinTemp(float minTemp) {
        this.minTemp = minTemp;
    }

    public float getMaxTemp() {
        return maxTemp;
    }

    public void setMaxTemp(float maxTemp) {
        this.maxTemp = maxTemp;
    }

    public String toString() {
        return this.month+" "+this.year+" temperatures ranged from "+this.minTemp+" to "+this.maxTemp;
    }
}
