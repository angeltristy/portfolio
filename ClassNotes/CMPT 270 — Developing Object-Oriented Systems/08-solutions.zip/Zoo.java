 /* ---------------------------------------------
  * Copyright (c) 2025 University of Saskatchewan
  * All Rights Reserved
  * --------------------------------------------- */

public class Zoo {

    private Damageable[] damageables;
    private int index = 0;

    public Zoo(){
        damageables = new Monster[10];
    }

    public void addMonster(Monster monster) {
        if(index < damageables.length){
            damageables[index] = monster;
            index++;
        }
    }

    public void damageAll(){
        for(int i = 0; i < index; i++){
            damageables[i].damage();
        }
    }

    public void monsterAttack(){
        for(int i = 0; i < index; i++){
            Damageable damageable = damageables[i];
            if(damageable instanceof Monster){
                ((Monster)damageable).attack();
            }
        }
    }
}
