 /* ---------------------------------------------
  * Copyright (c) 2025 University of Saskatchewan
  * All Rights Reserved
  * --------------------------------------------- */

public class Squiiirtle extends WaterMonster{


    public String toString(){
        return "Squiiirtle";
    }

    @Override
    public void attack() {
        System.out.println("Water tackle");
    }
}
