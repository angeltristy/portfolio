 /* ---------------------------------------------
  * Copyright (c) 2025 University of Saskatchewan
  * All Rights Reserved
  * --------------------------------------------- */

public class Peekatu extends ElectricMonster{

    public String toString() {
        return "Peekatu!";
    }

    @Override
    public void attack() {
        System.out.println("Thunder!");
    }
}
