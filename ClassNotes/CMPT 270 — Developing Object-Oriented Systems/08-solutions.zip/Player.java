 /* ---------------------------------------------
  * Copyright (c) 2025 University of Saskatchewan
  * All Rights Reserved
  * --------------------------------------------- */

public class Player implements Damageable{

    @Override
    public void damage() {

    }
}
