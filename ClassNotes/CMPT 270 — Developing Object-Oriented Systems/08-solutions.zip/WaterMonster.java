public abstract class WaterMonster extends Monster{
}
