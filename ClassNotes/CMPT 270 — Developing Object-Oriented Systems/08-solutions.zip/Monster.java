 /* ---------------------------------------------
  * Copyright (c) 2025 University of Saskatchewan
  * All Rights Reserved
  * --------------------------------------------- */

public abstract class Monster implements Damageable{

    public abstract void attack();
    public void damage(){
        System.out.println("Damaging..." + this.getClass().getName());
    }
}
