 /* ---------------------------------------------
  * Copyright (c) 2025 University of Saskatchewan
  * All Rights Reserved
  * --------------------------------------------- */

public class Starfishy extends WaterMonster{

    public String toString(){
        return "Starfishy";
    }

    @Override
    public void attack() {
        System.out.println("Water gun");
    }
}
