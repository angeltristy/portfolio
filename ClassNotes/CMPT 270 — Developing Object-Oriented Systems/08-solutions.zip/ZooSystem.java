 /* ---------------------------------------------
  * Copyright (c) 2025 University of Saskatchewan
  * All Rights Reserved
  * --------------------------------------------- */

public class ZooSystem {


    public static void main(String[] args) {
        Zoo zoo = new Zoo();

        Peekatu peekatu = new Peekatu();
        Starfishy starfishy = new Starfishy();
        Squiiirtle squiiirtle = new Squiiirtle();

        WaterMonster waterMonster = starfishy;
        Monster monster = squiiirtle;

        zoo.addMonster(peekatu);
        zoo.addMonster(waterMonster);
        zoo.addMonster(monster);
        zoo.addMonster(new Squiiirtle());

        zoo.damageAll();
        zoo.monsterAttack();
    }
}
